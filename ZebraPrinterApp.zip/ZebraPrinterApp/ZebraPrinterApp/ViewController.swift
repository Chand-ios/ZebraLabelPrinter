//
//  ViewController.swift
//  Zebra-App
//
//  Created by Ible on 21/03/22.
//

import UIKit
import Foundation
import ExternalAccessory
import UIKit
import AVFoundation

class ViewController: UIViewController {

    weak var printer: (ZebraPrinter & NSObjectProtocol)?
    var barcodeImage = UIImageView()
    var zebraOrderID : String!
    var imgVVV : UIImage!
    var itemlabelsList:NSArray!

//    let pleasewaitmp3 = URL(fileURLWithPath: Bundle.main.path(forResource: "pleasewait", ofType: "mp3")!)
//    let notconnectedmp3 = URL(fileURLWithPath: Bundle.main.path(forResource: "notconnected", ofType: "mp3")!)
//    let connectedmp3 = URL(fileURLWithPath: Bundle.main.path(forResource: "connected", ofType: "mp3")!)

    var audioPlayer = AVAudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        EAAccessoryManager.shared().registerForLocalNotifications()
        let bluetoohPrinterArr = EAAccessoryManager.shared().connectedAccessories
        let printer = bluetoohPrinterArr.first
    }


    //MARK: - Barcode Print.
    func getLanguageName(_ language: PrinterLanguage) -> String? {
        if language == PRINTER_LANGUAGE_ZPL {
            return "ZPL"
        } else {
            return "CPCL"
        }
    }
    
    @IBAction func singleAction(_ sender: Any) {
       // singleLabelPrint()
        let thread = Thread(target:self, selector:#selector(singleLabelPrint), object:nil)
            thread.start()
    }
    
    @IBAction func multipleAction(_ sender: Any) {
    }
    @objc func MultipleLabelPrint(){

            EAAccessoryManager.shared().registerForLocalNotifications()
            let bluetoohPrinterArr = EAAccessoryManager.shared().connectedAccessories
            let printer = bluetoohPrinterArr.first
            DispatchQueue.main.async() {
            }
            autoreleasepool{
                let connection:MfiBtPrinterConnection = MfiBtPrinterConnection(serialNumber: printer?.serialNumber)
                
                let open = connection.open()
                if(open)//connection.isConnected())
                {
                    do {
                      //  progressHUD.show()
                        //    try SGD.SET("bluetooth.page_scan_window", withValue: "60", andWithPrinterConnection: connection)
                        let  printer   =  try ZebraPrinterFactory.getInstance(connection)
                        let lang =  printer.getControlLanguage()
                        
                        if(lang != PRINTER_LANGUAGE_CPCL){
                            
                            do {
//                                self.audioPlayer = try AVAudioPlayer(contentsOf: self.connectedmp3)
//                                self.audioPlayer.play()
                                   } catch {
                                      // couldn't load file :(
                                   }
                        
                           for i in itemlabelsList{
                                    let s = i as! String//barcodeListItemSTR!
                                    let s1 = "^FD"
                                    let s2 = "^FS"
                               let s3 = s1 + s + s2
                            print(s)

                        // let footer = "^XA^PON^PW400^MNN^LL600^LH0,0" + "\r\n" + "^FO50,470" + "\r\n" + "^B3N,N,45,Y,N" + "\r\n" + s3 + "\r\n" + "^XZ"
                      //  let footer = "^XA^PON^PW500^MNN^LL600^LH0,0" + "\r\n" + "^FO10,270" + "\r\n" + "^B3N,N,40,Y,N" + "\r\n" + s3 + "\r\n" + "^XZ"
                               let footer = "^XA^PON^PW900^MNN^LL210^LH0,5" + "^FO10,80" + "^B3N,N,40,Y,N" + s3 + "^XZ"

                           // let footer = "^XA" + "^FO70,650" + "^B3N,N,60,Y,N" + s3 + "^XZ"
                            let tool = printer.getToolsUtil()
                          //  try  tool?.sendCommand("^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDMEMO^FS^XZ")
                            try tool?.sendCommand(footer)
                            }
                           // progressHUD.hide()
                        }
                    } catch {
                        print(error)
//                        let alert = UIAlertController(title: "Could not connect to printer.", message: "If you do not see your printer here, you need to make sure it is configured in your iOS settings.   Go to Settings > Bluetooth and pair with your printer.", preferredStyle: .alert)
//                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                       // self.present(alert, animated: true)
                        print("error")
                    }
                    connection.close()
                }
                else{
                    DispatchQueue.main.async() {
                        do {
//                            self.audioPlayer = try AVAudioPlayer(contentsOf: self.notconnectedmp3)
//                            self.audioPlayer.play()
                               } catch {
                                  // couldn't load file :(
                               }
                        let alert = UIAlertController(title: "Printer not connected", message: "If you do not see your printer here, you need to make sure it is configured in your iOS settings.   Go to Settings > Bluetooth and pair with your printer.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                        self.present(alert, animated: true)
                        print("Not Connected")
                        
                    }
            }
            }
        
    }

    @objc func singleLabelPrint(){

            EAAccessoryManager.shared().registerForLocalNotifications()
        let   bluetoohPrinterArr = EAAccessoryManager.shared().connectedAccessories
            let printer = bluetoohPrinterArr.first
            DispatchQueue.main.async() {
            }
            autoreleasepool{
                let connection:MfiBtPrinterConnection = MfiBtPrinterConnection(serialNumber: printer?.serialNumber)
                
                let open = connection.open()
                if(open)//connection.isConnected())
                {
                    do {
                      //  progressHUD.show()
                        //    try SGD.SET("bluetooth.page_scan_window", withValue: "60", andWithPrinterConnection: connection)
                        let  printer   =  try ZebraPrinterFactory.getInstance(connection)
                        let lang =  printer.getControlLanguage()
                        
                        if(lang != PRINTER_LANGUAGE_CPCL){
                            
                            do {
//                                self.audioPlayer = try AVAudioPlayer(contentsOf: self.connectedmp3)
//                                self.audioPlayer.play()
                                   } catch {
                                      // couldn't load file :(
                                   }
                        
                                    let s = "WR-7983"//"zebraOrderID"!
                                    let s1 = "^FD"
                                    let s2 = "^FS"
                                    let s3 = s1 + s + s2

                            //        "^XA^POI^LL600" + "\r\n"
                            let footer = "^XA^PON^PW500^MNN^LL215^LH0,0" + "^FO10,80" + "^B3N,N,40,Y,N" + s3 + "^XZ"
                         //   let footer = "^XA" + "^FO50,50" + "^B3N,N,40,Y,N" + s3 + "^XZ"
                            let tool = printer.getToolsUtil()
                          //  try  tool?.sendCommand("^XA^FO17,16^GB379,371,8^FS^FT65,255^A0N,135,134^FDMEMO^FS^XZ")
                            try tool?.sendCommand(footer)
                        //    progressHUD.hide()
                        }
                    } catch {
                        print(error)
                        do {
//                            self.audioPlayer = try AVAudioPlayer(contentsOf: self.notconnectedmp3)
//                            self.audioPlayer.play()
                               } catch {
                                  // couldn't load file :(
                               }
                        let alert = UIAlertController(title: "Could not connect to printer.", message: "If you do not see your printer here, you need to make sure it is configured in your iOS settings.   Go to Settings > Bluetooth and pair with your printer.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                       // self.present(alert, animated: true)
                        print("Could not connect to printer")
                    }
                    connection.close()
                }
                else{
                    DispatchQueue.main.async() {
                        
                        do {
//                            self.audioPlayer = try AVAudioPlayer(contentsOf: self.notconnectedmp3)
//                            self.audioPlayer.play()
                               } catch {
                                  // couldn't load file :(
                               }
                        
                        let alert = UIAlertController(title: "Printer not connected", message: "If you do not see your printer here, you need to make sure it is configured in your iOS settings.   Go to Settings > Bluetooth and pair with your printer.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
                        self.present(alert, animated: true)
                        print("Not Connected")
                    }
            }
            }
        
    }
}

